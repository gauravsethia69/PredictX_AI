import json
import urllib.request

payload = {
    "machine_id": "MACHINE-001",
    "temperature": 29,
    "vibration": 0,
    "current": 0.317,
    "sound": 613,
    "motor_running": True,
    "source": "esp32",
    "health": 88,
    "machine_status": "GOOD",
    "failure_probability": 6,
    "diagnosis": "Healthy Machine",
    "recommendation": "Normal Operation",
    "failure_stage": "Minor Deviation",
    "remaining_life_hours": 200,
    "prediction_explanation": "All sensors within learned baseline.",
}

request = urllib.request.Request(
    "http://127.0.0.1:8000/api/sensor-data",
    data=json.dumps(payload).encode("utf-8"),
    headers={"Content-Type": "application/json"},
    method="POST",
)

with urllib.request.urlopen(request) as response:
    print(response.status)
    print(response.read().decode())
